import sqlite3

# Connect to the database (creates it if it doesn't exist)
conn = sqlite3.connect('library.db')
cursor = conn.cursor()

# Create Users table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL, -- 'student', 'faculty', 'librarian'
    student_id INTEGER UNIQUE -- Unique student ID (for students only)
)
''')

# Create Books table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER UNIQUE, -- Unique book ID
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    quantity INTEGER NOT NULL
)
''')

# Create Branches table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
)
''')

# Create IssuedBooks table
cursor.execute('''
CREATE TABLE IF NOT EXISTS IssuedBooks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    issue_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    return_date TEXT,
    FOREIGN KEY (book_id) REFERENCES Books(id),
    FOREIGN KEY (student_id) REFERENCES Users(id)
)
''')

# Create Fines table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Fines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    paid BOOLEAN NOT NULL DEFAULT 0, -- 0 = unpaid, 1 = paid
    FOREIGN KEY (student_id) REFERENCES Users(id)
)
''')

# Commit changes and close the connection
conn.commit()
conn.close()

print("Database schema initialized successfully!")