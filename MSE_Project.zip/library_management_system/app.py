from flask import Flask, render_template, request, redirect, url_for, session, flash
import sqlite3
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for session management

# Database connection
def get_db_connection():
    conn = sqlite3.connect('library.db')
    conn.row_factory = sqlite3.Row
    return conn

# Home page (Login)
@app.route('/')
def home():
    return render_template('login.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_type = request.form['user_type']  # 'student_faculty' or 'librarian'

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM Users WHERE username = ? AND password = ? AND role = ?', 
                            (username, password, 'student' if user_type == 'student_faculty' else 'librarian')).fetchone()
        conn.close()

        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username, password, or user type', 'error')
            return redirect(url_for('login'))

    return render_template('login.html')

# Dashboard route
@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    role = session['role']
    conn = get_db_connection()

    if role == 'student':
        # Fetch available books for students/faculty
        books = conn.execute('SELECT * FROM Books WHERE quantity > 0').fetchall()
        # Fetch reports (issued books with due dates and penalties)
        reports = conn.execute('''
            SELECT Books.title, IssuedBooks.issue_date, IssuedBooks.due_date, IssuedBooks.return_date, Fines.amount, Fines.paid
            FROM IssuedBooks
            LEFT JOIN Books ON IssuedBooks.book_id = Books.id
            LEFT JOIN Fines ON IssuedBooks.student_id = Fines.student_id
            WHERE IssuedBooks.student_id = ?
        ''', (session['user_id'],)).fetchall()
    else:
        # Librarian dashboard (no books or reports)
        books = []
        reports = []

    conn.close()
    return render_template('dashboard.html', role=role, books=books, reports=reports)

# Search Books route (Students/Faculty)
@app.route('/search_books', methods=['GET', 'POST'])
def search_books():
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))

    conn = get_db_connection()
    if request.method == 'POST':
        search_query = request.form['search_query']
        books = conn.execute('SELECT * FROM Books WHERE title LIKE ? OR author LIKE ?', 
                             (f'%{search_query}%', f'%{search_query}%')).fetchall()
    else:
        books = conn.execute('SELECT * FROM Books WHERE quantity > 0').fetchall()

    conn.close()
    return render_template('search_books.html', books=books)

# Student Reports route
@app.route('/student/reports')
def student_reports():
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))

    student_id = session['user_id']
    conn = get_db_connection()
    reports = conn.execute('''
        SELECT Books.title, IssuedBooks.issue_date, IssuedBooks.due_date, IssuedBooks.return_date, Fines.amount, Fines.paid
        FROM IssuedBooks
        LEFT JOIN Books ON IssuedBooks.book_id = Books.id
        LEFT JOIN Fines ON IssuedBooks.student_id = Fines.student_id
        WHERE IssuedBooks.student_id = ?
    ''', (student_id,)).fetchall()
    conn.close()
    return render_template('student_reports.html', reports=reports)

# Add Book route (Librarian only)
@app.route('/librarian/add_book', methods=['GET', 'POST'])
def add_book():
    if 'user_id' not in session or session['role'] != 'librarian':
        return redirect(url_for('login'))

    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        quantity = int(request.form['quantity'])

        conn = get_db_connection()
        conn.execute('INSERT INTO Books (title, author, quantity) VALUES (?, ?, ?)', (title, author, quantity))
        conn.commit()
        conn.close()

        flash('Book added successfully!', 'success')
        return redirect(url_for('add_book'))

    return render_template('librarian_add_book.html')

# Remove Book route (Librarian only)
@app.route('/librarian/remove_book', methods=['GET', 'POST'])
def remove_book():
    if 'user_id' not in session or session['role'] != 'librarian':
        return redirect(url_for('login'))

    conn = get_db_connection()
    if request.method == 'POST':
        book_id = int(request.form['book_id'])
        conn.execute('DELETE FROM Books WHERE id = ?', (book_id,))
        conn.commit()
        conn.close()

        flash('Book removed successfully!', 'success')
        return redirect(url_for('remove_book'))

    books = conn.execute('SELECT * FROM Books').fetchall()
    conn.close()
    return render_template('librarian_remove_book.html', books=books)

# Change Password route
@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        if new_password != confirm_password:
            flash('Passwords do not match!', 'error')
            return redirect(url_for('change_password'))

        conn = get_db_connection()
        conn.execute('UPDATE Users SET password = ? WHERE id = ?', (new_password, session['user_id']))
        conn.commit()
        conn.close()

        flash('Password changed successfully!', 'success')
        return redirect(url_for('dashboard'))

    return render_template('change_password.html')

# Issue Book route (Librarian only)
@app.route('/librarian/issue_book', methods=['GET', 'POST'])
def issue_book():
    if 'user_id' not in session or session['role'] != 'librarian':
        return redirect(url_for('login'))

    if request.method == 'POST':
        student_id = int(request.form['student_id'])
        book_id = int(request.form['book_id'])
        issue_date = datetime.now().strftime('%Y-%m-%d')
        due_date = (datetime.now() + timedelta(days=14)).strftime('%Y-%m-%d')  # 14 days from today

        conn = get_db_connection()
        conn.execute('INSERT INTO IssuedBooks (book_id, student_id, issue_date, due_date) VALUES (?, ?, ?, ?)', 
                     (book_id, student_id, issue_date, due_date))
        conn.commit()
        conn.close()

        flash('Book issued successfully!', 'success')
        return redirect(url_for('issue_book'))

    return render_template('librarian_issue_book.html')

# Add Penalty route (Librarian only)
@app.route('/librarian/add_penalty', methods=['GET', 'POST'])
def add_penalty():
    if 'user_id' not in session or session['role'] != 'librarian':
        return redirect(url_for('login'))

    if request.method == 'POST':
        student_id = int(request.form['student_id'])
        amount = float(request.form['amount'])

        conn = get_db_connection()
        conn.execute('INSERT INTO Fines (student_id, amount) VALUES (?, ?)', (student_id, amount))
        conn.commit()
        conn.close()

        flash('Penalty added successfully!', 'success')
        return redirect(url_for('add_penalty'))

    return render_template('librarian_add_penalty.html')

# Add Student/Faculty route (Librarian only)
@app.route('/librarian/add_user', methods=['GET', 'POST'])
def add_user():
    if 'user_id' not in session or session['role'] != 'librarian':
        return redirect(url_for('login'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']  # 'student' or 'faculty'

        conn = get_db_connection()
        conn.execute('INSERT INTO Users (username, password, role) VALUES (?, ?, ?)', (username, password, role))
        conn.commit()
        conn.close()

        flash('User added successfully!', 'success')
        return redirect(url_for('add_user'))

    return render_template('librarian_add_user.html')


# Logout route
@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)