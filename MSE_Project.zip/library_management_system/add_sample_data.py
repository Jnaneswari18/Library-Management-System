import sqlite3

# Connect to the database
conn = sqlite3.connect('library.db')
cursor = conn.cursor()

# Delete existing data
cursor.execute('DELETE FROM Users;')
cursor.execute('DELETE FROM Books;')
cursor.execute('DELETE FROM Branches;')

# Add sample users
cursor.execute('''
INSERT INTO Users (username, password, role, student_id)
VALUES
    ('student1', 'password123', 'student', 1001),  -- student_id as integer
    ('faculty1', 'password123', 'faculty', NULL),  -- faculty has no student_id
    ('librarian1', 'password123', 'librarian', NULL)  -- librarian has no student_id
''')

# Add sample books
cursor.execute('''
INSERT INTO Books (book_id, title, author, quantity)
VALUES
    (101, 'Python Programming', 'John Doe', 5),  -- book_id as integer
    (102, 'Web Development', 'Jane Smith', 3),   -- book_id as integer
    (103, 'Database Systems', 'Alice Johnson', 7)  -- book_id as integer
''')

# Add sample branches
cursor.execute('''
INSERT INTO Branches (name)
VALUES
    ('Main Branch'),
    ('City Branch')
''')

# Commit changes and close the connection
conn.commit()
conn.close()

print("Sample data added successfully!")