import sqlite3

# Connect to the database
conn = sqlite3.connect('library.db')
cursor = conn.cursor()

# Create Users table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    role TEXT NOT NULL, -- 'student', 'librarian'
    student_id TEXT UNIQUE -- Unique student ID (for students only)
)
''')

# Create Books table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id TEXT UNIQUE, -- Unique book ID
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    quantity INTEGER NOT NULL
)
''')

# Create Branches table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Branches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL
)
''')

# Create IssuedBooks table
cursor.execute('''
CREATE TABLE IF NOT EXISTS IssuedBooks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    book_id INTEGER NOT NULL,
    student_id INTEGER NOT NULL,
    issue_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    return_date TEXT,
    FOREIGN KEY (book_id) REFERENCES Books(id),
    FOREIGN KEY (student_id) REFERENCES Users(id)
)
''')

# Add due_date column to IssuedBooks table if it doesn't exist
try:
    cursor.execute('ALTER TABLE IssuedBooks ADD COLUMN due_date TEXT')
except sqlite3.OperationalError as e:
    print("Column already exists:", e)

# Add book_id column to Books table
try:
    cursor.execute('ALTER TABLE Books ADD COLUMN book_id TEXT UNIQUE')
except sqlite3.OperationalError as e:
    print("Column already exists:", e)

try:
    cursor.execute('ALTER TABLE Users ADD COLUMN student_id TEXT UNIQUE')
except sqlite3.OperationalError as e:
    print("Column already exists:", e)

# Create Fines table
cursor.execute('''
CREATE TABLE IF NOT EXISTS Fines (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    paid BOOLEAN NOT NULL DEFAULT 0, -- 0 = unpaid, 1 = paid
    FOREIGN KEY (student_id) REFERENCES Users(id)
)
''')

# Commit changes and close the connection
conn.commit()
conn.close()

print("Database schema updated successfully!")